-- Secure starter schema for Supabase/Postgres.
-- Run as project owner in Supabase SQL Editor. Review before production.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role text not null default 'user' check (role in ('admin', 'user')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid null references auth.users(id) on delete set null,
  target_id uuid null,
  action text not null,
  created_at timestamptz not null default now(),
  details jsonb not null default '{}'::jsonb
);

create index if not exists profiles_created_at_idx on public.profiles(created_at desc);
create index if not exists audit_logs_created_at_idx on public.audit_logs(created_at desc);
create index if not exists audit_logs_target_id_idx on public.audit_logs(target_id);

alter table public.profiles enable row level security;
alter table public.audit_logs enable row level security;

-- SECURITY DEFINER helper avoids recursive RLS checks on profiles.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Create profile automatically for each new auth user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'user')
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Audit profile mutations. Do not store passwords, tokens, or secrets in details.
create or replace function public.audit_profile_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor uuid;
  v_target uuid;
  v_action text;
  v_details jsonb;
begin
  v_actor := (select auth.uid());
  if (tg_op = 'INSERT') then
    v_target := new.id;
    v_action := 'profile_created';
    v_details := jsonb_build_object('role', new.role);
  elsif (tg_op = 'UPDATE') then
    v_target := new.id;
    v_action := 'profile_updated';
    v_details := jsonb_build_object(
      'email_changed', old.email is distinct from new.email,
      'role_changed', old.role is distinct from new.role
    );
  elsif (tg_op = 'DELETE') then
    v_target := old.id;
    v_action := 'profile_deleted';
    v_details := '{}'::jsonb;
  end if;

  insert into public.audit_logs(actor_id, target_id, action, details)
  values (v_actor, v_target, v_action, coalesce(v_details, '{}'::jsonb));

  if tg_op = 'DELETE' then return old; else return new; end if;
end;
$$;

drop trigger if exists audit_profiles_change on public.profiles;
create trigger audit_profiles_change
after insert or update or delete on public.profiles
for each row execute procedure public.audit_profile_change();

-- Access policies: users can read only their own profile; admins can read all.
drop policy if exists "profiles_read_self_or_admin" on public.profiles;
create policy "profiles_read_self_or_admin"
on public.profiles for select to authenticated
using (id = (select auth.uid()) or (select public.is_admin()));

-- Allow a user to update only their own non-privileged display fields.
-- This starter deliberately exposes no profile edit UI. Email changes should use Auth APIs.
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (email) on public.profiles to authenticated;

drop policy if exists "profiles_update_self_email" on public.profiles;
create policy "profiles_update_self_email"
on public.profiles for update to authenticated
using (id = (select auth.uid()))
with check (id = (select auth.uid()));

-- The app reads logs only when the caller is an admin; no client insert/update/delete.
revoke all on public.audit_logs from anon, authenticated;
grant select on public.audit_logs to authenticated;

drop policy if exists "audit_logs_admin_read" on public.audit_logs;
create policy "audit_logs_admin_read"
on public.audit_logs for select to authenticated
using ((select public.is_admin()));

-- Ensure ordinary authenticated users cannot grant themselves a role.
revoke update (role, id, created_at, updated_at) on public.profiles from authenticated;
grant usage, select on sequence public.audit_logs_id_seq to authenticated;
revoke insert, update, delete on public.audit_logs from anon, authenticated;

-- Keep updated_at current for any future profile update.
create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = ''
as $$ begin new.updated_at = now(); return new; end; $$;
drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute procedure public.set_updated_at();

-- Note: audit logs created by DB triggers have actor_id null when the action
-- is caused by a privileged service context without an authenticated JWT.
