 "use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: FormEvent) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) throw error;
      router.replace("/dashboard"); router.refresh();
    } catch (err) {
      setError("ورود موفق نشد. ایمیل/رمز را بررسی کن و اگر حساب تأیید نشده، ایمیل را تأیید کن.");
    } finally { setBusy(false); }
  }

  return <main><section className="panel"><h1>ورود امن</h1><p className="muted">رمز عبور در این برنامه ذخیره نمی‌شود؛ احراز هویت از طریق Supabase انجام می‌شود.</p>
    <form onSubmit={submit}>
      <label htmlFor="email">ایمیل</label><input id="email" type="email" autoComplete="email" required maxLength={254} value={email} onChange={e=>setEmail(e.target.value)} />
      <label htmlFor="password">رمز عبور</label><input id="password" type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} />
      {error && <p className="error" role="alert">{error}</p>}
      <p><button disabled={busy} type="submit">{busy ? "در حال بررسی…" : "ورود"}</button></p>
    </form><p><Link href="/reset-password">رمز را فراموش کرده‌ای؟</Link></p><p><Link href="/">بازگشت</Link></p>
  </section></main>;
}
