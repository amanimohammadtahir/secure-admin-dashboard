 "use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function ResetPasswordPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setMessage(""); setError(""); setBusy(true);
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/login` });
      if (error) throw error;
      setMessage("اگر این ایمیل در سیستم موجود باشد، دستور بازیابی ارسال می‌شود.");
    } catch { setError("درخواست فعلاً انجام نشد؛ تنظیمات ایمیل Supabase را بررسی کن."); }
    finally { setBusy(false); }
  }
  return <main><section className="panel"><h1>بازیابی رمز</h1><form onSubmit={submit}>
    <label htmlFor="email">ایمیل حساب</label><input id="email" type="email" autoComplete="email" required maxLength={254} value={email} onChange={e=>setEmail(e.target.value)} />
    {error && <p className="error" role="alert">{error}</p>}{message && <p role="status">{message}</p>}
    <p><button disabled={busy} type="submit">{busy ? "در حال ارسال…" : "ارسال دستور بازیابی"}</button></p>
  </form><Link href="/login">بازگشت به ورود</Link></section></main>;
}
