 "use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setMessage(""); setError(""); setBusy(true);
    try {
      if (password.length < 12) throw new Error("برای این نسخه، رمز عبور باید حداقل ۱۲ حرف داشته باشد.");
      const supabase = createClient();
      const { error } = await supabase.auth.signUp({ email: email.trim(), password });
      if (error) throw error;
      setMessage("اگر ثبت‌نام پذیرفته شده باشد، برای تأیید حساب ایمیل را بررسی کن. تا پیش از تأیید ایمیل ممکن است ورود ممکن نباشد.");
      setPassword("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "ثبت‌نام انجام نشد.");
    } finally { setBusy(false); }
  }

  return <main><section className="panel"><h1>ساخت حساب</h1><p className="muted">حساب تازه به‌صورت پیش‌فرض کاربر عادی است؛ نقش مدیر را فقط مالک دیتابیس تعیین می‌کند.</p>
    <form onSubmit={submit}>
      <label htmlFor="email">ایمیل</label><input id="email" type="email" autoComplete="email" required maxLength={254} value={email} onChange={e=>setEmail(e.target.value)} />
      <label htmlFor="password">رمز عبور (حداقل ۱۲ حرف)</label><input id="password" type="password" autoComplete="new-password" required minLength={12} value={password} onChange={e=>setPassword(e.target.value)} />
      {error && <p className="error" role="alert">{error}</p>}{message && <p className="success" role="status">{message}</p>}
      <p><button disabled={busy} type="submit">{busy ? "در حال ساخت…" : "ثبت‌نام"}</button></p>
    </form><p><Link href="/login">رفتن به ورود</Link></p>
  </section></main>;
}
