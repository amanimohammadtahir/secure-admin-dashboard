import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) redirect("/dashboard");

  return <main>
    <header><div><h1>پنل مدیریت امن</h1><p className="muted">مدیریت کاربران و گزارش‌های فعالیت اپلیکیشن</p></div></header>
    <section className="panel">
      <h2>شروع کار</h2>
      <p>برای ورود به پنل، از حساب تأییدشدهٔ خود استفاده کن. دسترسی‌ها در سرور و دیتابیس بررسی می‌شوند.</p>
      <div className="actions"><Link className="button" href="/login">ورود</Link><Link className="button secondary" href="/signup">ساخت حساب</Link></div>
      <p className="muted">نسخهٔ آغازین؛ برای فعال‌شدن، ابتدا پروژهٔ Supabase را طبق README تنظیم کن.</p>
    </section>
  </main>;
}
