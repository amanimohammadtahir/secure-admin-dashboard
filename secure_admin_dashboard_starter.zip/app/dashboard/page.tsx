import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import SignOutButton from "./sign-out-button";

export const dynamic = "force-dynamic";

type Profile = { id: string; email: string; role: "admin" | "user"; created_at: string };
type Audit = { id: number; actor_id: string | null; target_id: string | null; action: string; created_at: string; details: unknown };

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("id,email,role,created_at").eq("id", user.id).maybeSingle();
  if (!profile) return <main><section className="panel"><h1>حساب آماده نیست</h1><p>پروفایل هنوز ساخته نشده یا ایمیل را تأیید نکرده‌ای. یک بار خارج و دوباره وارد شو؛ اگر مشکل ماند، مالک پروژه باید تنظیمات دیتابیس را بررسی کند.</p><SignOutButton /></section></main>;

  let users: Profile[] = [];
  let logs: Audit[] = [];
  if (profile.role === "admin") {
    const [usersResult, logsResult] = await Promise.all([
      supabase.from("profiles").select("id,email,role,created_at").order("created_at", { ascending: false }).limit(200),
      supabase.from("audit_logs").select("id,actor_id,target_id,action,created_at,details").order("created_at", { ascending: false }).limit(100)
    ]);
    users = (usersResult.data ?? []) as Profile[];
    logs = (logsResult.data ?? []) as Audit[];
  }

  return <main>
    <header><div><h1>داشبورد</h1><p className="muted">واردشده با: {profile.email}</p></div><SignOutButton /></header>
    <section className="grid">
      <div className="stat"><div className="muted">نقش حساب</div><h2>{profile.role === "admin" ? "مدیر" : "کاربر"}</h2></div>
      <div className="stat"><div className="muted">وضعیت نشست</div><h2>واردشده</h2></div>
      <div className="stat"><div className="muted">تاریخ ساخت حساب</div><h2>{new Date(profile.created_at).toLocaleDateString("fa-AF")}</h2></div>
    </section>
    {profile.role === "admin" ? <>
      <section className="panel"><h2>مدیریت کاربران</h2><p className="muted">برای محافظت از حساب‌ها، تغییر نقش از این صفحه فعال نیست؛ نقش مدیر فقط از مسیر امن مالک دیتابیس تعیین می‌شود.</p>
        <div className="table-wrap"><table><thead><tr><th>ایمیل</th><th>نقش</th><th>تاریخ ایجاد</th></tr></thead><tbody>
          {users.map(u=><tr key={u.id}><td>{u.email}</td><td>{u.role === "admin" ? "مدیر" : "کاربر"}</td><td>{new Date(u.created_at).toLocaleDateString("fa-AF")}</td></tr>)}
          {!users.length && <tr><td colSpan={3}>کاربری پیدا نشد یا اجازهٔ خواندن داده‌ها وجود ندارد.</td></tr>}
        </tbody></table></div>
      </section>
      <section className="panel"><h2>گزارش حسابرسی</h2><p className="muted">آخرین ۱۰۰ رویداد ثبت‌شده در تغییرات پروفایل. گزارش‌ها در دیتابیس نوشته می‌شوند.</p>
        <div className="table-wrap"><table><thead><tr><th>رویداد</th><th>شناسهٔ هدف</th><th>زمان</th><th>جزئیات</th></tr></thead><tbody>
          {logs.map(log=><tr key={log.id}><td>{log.action}</td><td>{log.target_id ?? "—"}</td><td>{new Date(log.created_at).toLocaleString("fa-AF")}</td><td><code>{JSON.stringify(log.details)}</code></td></tr>)}
          {!logs.length && <tr><td colSpan={4}>هنوز رویدادی ثبت نشده است.</td></tr>}
        </tbody></table></div>
      </section>
    </> : <section className="panel"><h2>خوش آمدی</h2><p>حساب تو دسترسی کاربر عادی دارد. اطلاعات مدیریتی و گزارش حسابرسی برای این نقش قابل مشاهده نیست.</p></section>}
    <section className="panel"><h2>وضعیت امنیت</h2><p>دسترسی به اطلاعات در دیتابیس با سیاست‌های RLS محدود می‌شود. این صفحه به‌تنهایی تضمین امنیت کامل نیست؛ تنظیمات Supabase و میزبان نیز باید درست باشد.</p></section>
  </main>;
}
